# Audiología – Sistema (Vite + React + Tailwind)

## Pasos
1. Requisitos: **Node.js 18+**.
2. Instalar dependencias:
   ```bash
   npm install
   npm run dev
   ```
3. Abre la URL de Vite (p.ej. http://localhost:5173).

## Estructura
- `src/App.jsx`: componente principal. Aquí pegaremos/iteraremos tu UI completa.
- Tailwind ya está configurado (`tailwind.config.js`, `postcss.config.js`, `src/index.css`).

