import React, { useState, useEffect } from 'react';

// Iconos SVG personalizados
const ChevronRight = (props) => <svg {...props} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" /></svg>;
const ChevronDown = (props) => <svg {...props} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" /></svg>;
const Plus = (props) => <svg {...props} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" /></svg>;
const Edit2 = (props) => <svg {...props} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" /></svg>;
const Save = (props) => <svg {...props} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-3m-1 4l-3 3m0 0l-3-3m3 3V4" /></svg>;
const X = (props) => <svg {...props} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>;
const Search = (props) => <svg {...props} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>;
const Users = (props) => <svg {...props} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" /></svg>;
const FileText = (props) => <svg {...props} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>;
const Headphones = (props) => <svg {...props} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" /></svg>;
const Package = (props) => <svg {...props} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" /></svg>;
const MessageCircle = (props) => <svg {...props} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" /></svg>;
const Heart = (props) => <svg {...props} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" /></svg>;
const Download = (props) => <svg {...props} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>;
const Upload = (props) => <svg {...props} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" /></svg>;
const Image = (props) => <svg {...props} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>;
const PlusCircle = (props) => <svg {...props} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v3m0 0v3m0-3h3m-3 0H9m12 0a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>;
const LinkIcon = (props) => <svg {...props} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" /></svg>;
const Paperclip = (props) => <svg {...props} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13" /></svg>;
const Pencil = (props) => <svg {...props} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" /></svg>;

const AudiologiaApp = () => {
  const [activeSection, setActiveSection] = useState('centros_exclusivos');
  const [activeCentro, setActiveCentro] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [logoUrl, setLogoUrl] = useState('');
  const [companyName, setCompanyName] = useState('AUDIOLOGÍA');
  const [showLogoModal, setShowLogoModal] = useState(false);
  const [showSectionEditModal, setShowSectionEditModal] = useState(false);
  const [editingSectionId, setEditingSectionId] = useState(null);
  const [editingSectionName, setEditingSectionName] = useState('');
  const [showCentroModal, setShowCentroModal] = useState(false);
  const [newCentroNombre, setNewCentroNombre] = useState('');
  const [newCentroDelegado, setNewCentroDelegado] = useState('');
  const [newCentroAudiologo, setNewCentroAudiologo] = useState('');
  const [newCentroFranquiciaSucursal, setNewCentroFranquiciaSucursal] = useState('');
  const [showCentrosDropdown, setShowCentrosDropdown] = useState(false);
  const [editingCentroId, setEditingCentroId] = useState(null);
  const [editingCentroNombre, setEditingCentroNombre] = useState('');
  const [editingCentroDelegado, setEditingCentroDelegado] = useState('');
  const [editingCentroAudiologo, setEditingCentroAudiologo] = useState('');
  const [editingCentroFranquiciaSucursal, setEditingCentroFranquiciaSucursal] = useState('');
  const [centros, setCentros] = useState([
    { id: 1, nombre: 'Centro Madrid Norte', delegado: 'Ana Martínez', audiologo: 'Dr. García', franquiciaSucursal: 'Franquicia', color: 'bg-blue-100 border-blue-400 text-blue-800' },
    { id: 2, nombre: 'Centro Barcelona Centro', delegado: 'Carlos Ruiz', audiologo: 'Dra. López', franquiciaSucursal: 'Sucursal', color: 'bg-green-100 border-green-400 text-green-800' }
  ]);

  const coloresCentros = [
    'bg-blue-100 border-blue-400 text-blue-800',
    'bg-green-100 border-green-400 text-green-800',
    'bg-purple-100 border-purple-400 text-purple-800',
    'bg-orange-100 border-orange-400 text-orange-800',
    'bg-pink-100 border-pink-400 text-pink-800',
    'bg-indigo-100 border-indigo-400 text-indigo-800',
    'bg-yellow-100 border-yellow-400 text-yellow-800',
    'bg-red-100 border-red-400 text-red-800',
    'bg-teal-100 border-teal-400 text-teal-800',
    'bg-cyan-100 border-cyan-400 text-cyan-800',
    'bg-lime-100 border-lime-400 text-lime-800',
    'bg-rose-100 border-rose-400 text-rose-800'
  ];
  
  const [data, setData] = useState({
    centros_exclusivos: {
      title: 'CENTROS EXCLUSIVOS',
      icon: FileText,
      color: 'from-red-600 to-red-700',
      requiresCentro: true,
      centrosData: {
        1: { 
          customFields: [], 
          accionesResultado: [
            {
              id: 1,
              fecha: '',
              accion: '',
              derivacion: 0,
              cita: 0,
              observaciones: ''
            }
          ],
          formaciones: [
            { id: 1, fecha: '', asistencia: '', titulo: '', aplicacion: '' },
            { id: 2, fecha: '', asistencia: '', titulo: '', aplicacion: '' },
            { id: 3, fecha: '', asistencia: '', titulo: '', aplicacion: '' },
            { id: 4, fecha: '', asistencia: '', titulo: '', aplicacion: '' },
            { id: 5, fecha: '', asistencia: '', titulo: '', aplicacion: '' },
            { id: 6, fecha: '', asistencia: '', titulo: '', aplicacion: '' },
            { id: 7, fecha: '', asistencia: '', titulo: '', aplicacion: '' },
            { id: 8, fecha: '', asistencia: '', titulo: '', aplicacion: '' },
            { id: 9, fecha: '', asistencia: '', titulo: '', aplicacion: '' },
            { id: 10, fecha: '', asistencia: '', titulo: '', aplicacion: '' }
          ],
          procesosPersonalizados: [
            {
              id: 1,
              nombrePaquete: '',
              descripcion: '',
              puntuacion: '',
              observaciones: '',
              fechaVisita: '',
              archivos: [],
              enlaces: []
            }
          ]
        },
        2: { 
          customFields: [], 
          accionesResultado: [
            {
              id: 1,
              fecha: '',
              accion: '',
              derivacion: 0,
              cita: 0,
              observaciones: ''
            }
          ],
          formaciones: [
            { id: 1, fecha: '', asistencia: '', titulo: '', aplicacion: '' },
            { id: 2, fecha: '', asistencia: '', titulo: '', aplicacion: '' },
            { id: 3, fecha: '', asistencia: '', titulo: '', aplicacion: '' },
            { id: 4, fecha: '', asistencia: '', titulo: '', aplicacion: '' },
            { id: 5, fecha: '', asistencia: '', titulo: '', aplicacion: '' },
            { id: 6, fecha: '', asistencia: '', titulo: '', aplicacion: '' },
            { id: 7, fecha: '', asistencia: '', titulo: '', aplicacion: '' },
            { id: 8, fecha: '', asistencia: '', titulo: '', aplicacion: '' },
            { id: 9, fecha: '', asistencia: '', titulo: '', aplicacion: '' },
            { id: 10, fecha: '', asistencia: '', titulo: '', aplicacion: '' }
          ],
          procesosPersonalizados: [
            {
              id: 1,
              nombrePaquete: '',
              descripcion: '',
              puntuacion: '',
              observaciones: '',
              fechaVisita: '',
              archivos: [],
              enlaces: []
            }
          ]
        }
      }
    },
    centros_flop: {
      title: 'CENTROS FLOP',
      icon: Users,
      color: 'from-gray-600 to-gray-700',
      customFields: [],
      items: []
    },
    visitas_audio: {
      title: 'VISITAS AUDIO',
      icon: Headphones,
      color: 'from-red-500 to-red-600',
      customFields: [],
      items: []
    },
    mentoring_audio: {
      title: 'MENTORING AUDIO',
      icon: Edit2,
      color: 'from-gray-700 to-gray-800',
      customFields: [],
      items: []
    },
    producto_pedidos: {
      title: 'Producto / Pedidos / Devoluciones',
      icon: Package,
      color: 'from-red-700 to-red-800',
      customFields: [],
      items: []
    },
    comunicacion: {
      title: 'Comunicación',
      icon: MessageCircle,
      color: 'from-gray-500 to-gray-600',
      customFields: [],
      items: []
    },
    area_social: {
      title: 'Área Social y Colaboraciones',
      icon: Heart,
      color: 'from-red-600 to-red-700',
      customFields: [],
      items: []
    }
  });

  const [editingItem, setEditingItem] = useState(null);
  const [editTitle, setEditTitle] = useState('');
  const [editFecha, setEditFecha] = useState('');
  const [editAccion, setEditAccion] = useState('');
  const [editDerivacion, setEditDerivacion] = useState(0);
  const [editCita, setEditCita] = useState(0);
  const [editObservaciones, setEditObservaciones] = useState('');
  const [editCustomData, setEditCustomData] = useState({});
  const [editFiles, setEditFiles] = useState([]);
  const [editLinks, setEditLinks] = useState([]);
  
  // Estados para Acciones-Resultado
  const [editingAccionesResultado, setEditingAccionesResultado] = useState(false);
  const [accionesResultadoData, setAccionesResultadoData] = useState([]);
  const [draggedAccionIndex, setDraggedAccionIndex] = useState(null);
  
  // Estados para Formaciones
  const [editingFormacionId, setEditingFormacionId] = useState(null);
  const [formacionesData, setFormacionesData] = useState([]);
  const [draggedFormacionIndex, setDraggedFormacionIndex] = useState(null);
  
  // Estados para Procesos Personalizados
  const [procesosData, setProcesosData] = useState([]);
  const [draggedProcesoIndex, setDraggedProcesoIndex] = useState(null);
  const [procesoFiles, setProcesoFiles] = useState({});
  const [procesoLinks, setProcesoLinks] = useState({});
  const [newProcesoLinkUrl, setNewProcesoLinkUrl] = useState('');
  const [newProcesoLinkTitle, setNewProcesoLinkTitle] = useState('');
  const [editingProcesoId, setEditingProcesoId] = useState(null);
  const [showFieldModal, setShowFieldModal] = useState(false);
  const [newFieldName, setNewFieldName] = useState('');
  const [newLinkUrl, setNewLinkUrl] = useState('');
  const [newLinkTitle, setNewLinkTitle] = useState('');

  // Inicializar el primer centro cuando se carga la app
  useEffect(() => {
    if (activeSection === 'centros_exclusivos' && centros.length > 0 && !activeCentro) {
      setActiveCentro(centros[0].id);
    }
  }, []);

  // Cargar datos cuando cambia el centro activo
  useEffect(() => {
    if (activeSection === 'centros_exclusivos' && activeCentro && currentData) {
      setAccionesResultadoData(currentData.accionesResultado || [{
        id: 1,
        fecha: '',
        accion: '',
        derivacion: 0,
        cita: 0,
        observaciones: ''
      }]);
      setFormacionesData(currentData.formaciones || []);
      setProcesosData(currentData.procesosPersonalizados || [{
        id: 1,
        nombrePaquete: '',
        descripcion: '',
        puntuacion: '',
        observaciones: '',
        fechaVisita: '',
        archivos: [],
        enlaces: []
      }]);
    }
  }, [activeCentro, activeSection]);

  // Funciones para Acciones-Resultado
  const addAccion = () => {
    const newId = Math.max(...accionesResultadoData.map(a => a.id), 0) + 1;
    setAccionesResultadoData([...accionesResultadoData, {
      id: newId,
      fecha: '',
      accion: '',
      derivacion: 0,
      cita: 0,
      observaciones: ''
    }]);
  };

  const deleteAccion = (id) => {
    if (accionesResultadoData.length > 1) {
      setAccionesResultadoData(accionesResultadoData.filter(a => a.id !== id));
    }
  };

  const updateAccion = (id, field, value) => {
    setAccionesResultadoData(accionesResultadoData.map(a =>
      a.id === id ? { ...a, [field]: value } : a
    ));
  };

  const handleDragStartAccion = (index) => {
    setDraggedAccionIndex(index);
  };

  const handleDragOverAccion = (e, index) => {
    e.preventDefault();
    if (draggedAccionIndex === null || draggedAccionIndex === index) return;
    
    const items = [...accionesResultadoData];
    const draggedItem = items[draggedAccionIndex];
    items.splice(draggedAccionIndex, 1);
    items.splice(index, 0, draggedItem);
    
    setAccionesResultadoData(items);
    setDraggedAccionIndex(index);
  };

  const handleDragEndAccion = () => {
    setDraggedAccionIndex(null);
  };

  const saveAccionesResultado = () => {
    if (activeData.requiresCentro && activeCentro) {
      setData(prev => ({
        ...prev,
        [activeSection]: {
          ...prev[activeSection],
          centrosData: {
            ...prev[activeSection].centrosData,
            [activeCentro]: {
              ...prev[activeSection].centrosData[activeCentro],
              accionesResultado: accionesResultadoData
            }
          }
        }
      }));
      setEditingAccionesResultado(false);
    }
  };

  // Funciones para Formaciones
  const updateFormacion = (id, field, value) => {
    const updatedFormaciones = formacionesData.map(f => 
      f.id === id ? { ...f, [field]: value } : f
    );
    setFormacionesData(updatedFormaciones);
  };

  const handleDragStartFormacion = (index) => {
    setDraggedFormacionIndex(index);
  };

  const handleDragOverFormacion = (e, index) => {
    e.preventDefault();
    if (draggedFormacionIndex === null || draggedFormacionIndex === index) return;
    
    const items = [...formacionesData];
    const draggedItem = items[draggedFormacionIndex];
    items.splice(draggedFormacionIndex, 1);
    items.splice(index, 0, draggedItem);
    
    setFormacionesData(items);
    setDraggedFormacionIndex(index);
  };

  const handleDragEndFormacion = () => {
    setDraggedFormacionIndex(null);
  };

  const saveFormaciones = () => {
    if (activeData.requiresCentro && activeCentro) {
      setData(prev => ({
        ...prev,
        [activeSection]: {
          ...prev[activeSection],
          centrosData: {
            ...prev[activeSection].centrosData,
            [activeCentro]: {
              ...prev[activeSection].centrosData[activeCentro],
              formaciones: formacionesData
            }
          }
        }
      }));
      setEditingFormacionId(null);
    }
  };

  // Funciones para Procesos Personalizados
  const addProceso = () => {
    const newId = Math.max(...procesosData.map(p => p.id), 0) + 1;
    setProcesosData([...procesosData, {
      id: newId,
      nombrePaquete: '',
      descripcion: '',
      puntuacion: '',
      observaciones: '',
      fechaVisita: '',
      archivos: [],
      enlaces: []
    }]);
  };

  const deleteProceso = (id) => {
    if (procesosData.length > 1) {
      setProcesosData(procesosData.filter(p => p.id !== id));
    }
  };

  const updateProceso = (id, field, value) => {
    setProcesosData(procesosData.map(p =>
      p.id === id ? { ...p, [field]: value } : p
    ));
  };

  const handleProcesoFileUpload = (procesoId, event) => {
    const files = Array.from(event.target.files);
    const newFiles = files.map(file => ({
      name: file.name,
      size: file.size,
      type: file.type,
      id: Date.now() + Math.random()
    }));
    
    setProcesosData(procesosData.map(p =>
      p.id === procesoId ? { ...p, archivos: [...(p.archivos || []), ...newFiles] } : p
    ));
  };

  const removeProcesoFile = (procesoId, fileId) => {
    setProcesosData(procesosData.map(p =>
      p.id === procesoId ? { ...p, archivos: (p.archivos || []).filter(f => f.id !== fileId) } : p
    ));
  };

  const addProcesoLink = (procesoId) => {
    if (newProcesoLinkUrl.trim()) {
      const newLink = {
        url: newProcesoLinkUrl,
        title: newProcesoLinkTitle || newProcesoLinkUrl,
        id: Date.now()
      };
      
      setProcesosData(procesosData.map(p =>
        p.id === procesoId ? { ...p, enlaces: [...(p.enlaces || []), newLink] } : p
      ));
      
      setNewProcesoLinkUrl('');
      setNewProcesoLinkTitle('');
      setEditingProcesoId(null);
    }
  };

  const removeProcesoLink = (procesoId, linkId) => {
    setProcesosData(procesosData.map(p =>
      p.id === procesoId ? { ...p, enlaces: (p.enlaces || []).filter(l => l.id !== linkId) } : p
    ));
  };

  const handleDragStartProceso = (index) => {
    setDraggedProcesoIndex(index);
  };

  const handleDragOverProceso = (e, index) => {
    e.preventDefault();
    if (draggedProcesoIndex === null || draggedProcesoIndex === index) return;
    
    const items = [...procesosData];
    const draggedItem = items[draggedProcesoIndex];
    items.splice(draggedProcesoIndex, 1);
    items.splice(index, 0, draggedItem);
    
    setProcesosData(items);
    setDraggedProcesoIndex(index);
  };

  const handleDragEndProceso = () => {
    setDraggedProcesoIndex(null);
  };

  const saveProcesos = () => {
    if (activeData.requiresCentro && activeCentro) {
      setData(prev => ({
        ...prev,
        [activeSection]: {
          ...prev[activeSection],
          centrosData: {
            ...prev[activeSection].centrosData,
            [activeCentro]: {
              ...prev[activeSection].centrosData[activeCentro],
              procesosPersonalizados: procesosData
            }
          }
        }
      }));
    }
  };

  const sections = Object.entries(data).map(([key, value]) => ({
    id: key,
    ...value
  }));

  const activeData = data[activeSection];
  
  // Para secciones que requieren centro, obtener los datos específicos del centro
  const getCurrentData = () => {
    if (activeData.requiresCentro && activeCentro) {
      return activeData.centrosData[activeCentro] || { 
        customFields: [], 
        accionesResultado: [{
          id: 1,
          fecha: '',
          accion: '',
          derivacion: 0,
          cita: 0,
          observaciones: ''
        }],
        formaciones: Array.from({length: 10}, (_, i) => ({
          id: i + 1,
          fecha: '',
          asistencia: '',
          titulo: '',
          aplicacion: ''
        })),
        procesosPersonalizados: [{
          id: 1,
          nombrePaquete: '',
          descripcion: '',
          puntuacion: '',
          observaciones: '',
          fechaVisita: '',
          archivos: [],
          enlaces: []
        }]
      };
    }
    return activeData;
  };
  
  const currentData = getCurrentData();

  const addNewCentro = () => {
    if (newCentroNombre.trim()) {
      if (centros.length >= 12) {
        alert('Has alcanzado el límite máximo de 12 centros');
        return;
      }
      
      const newId = Math.max(...centros.map(c => c.id), 0) + 1;
      const colorIndex = centros.length % coloresCentros.length;
      const newCentro = {
        id: newId,
        nombre: newCentroNombre.trim(),
        delegado: newCentroDelegado.trim(),
        audiologo: newCentroAudiologo.trim(),
        franquiciaSucursal: newCentroFranquiciaSucursal.trim(),
        color: coloresCentros[colorIndex]
      };
      
      setCentros([...centros, newCentro]);
      
      // Inicializar datos para el nuevo centro
      setData(prev => ({
        ...prev,
        centros_exclusivos: {
          ...prev.centros_exclusivos,
          centrosData: {
            ...prev.centros_exclusivos.centrosData,
            [newId]: { 
              customFields: [], 
              accionesResultado: [{
                id: 1,
                fecha: '',
                accion: '',
                derivacion: 0,
                cita: 0,
                observaciones: ''
              }],
              formaciones: Array.from({length: 10}, (_, i) => ({
                id: i + 1,
                fecha: '',
                asistencia: '',
                titulo: '',
                aplicacion: ''
              })),
              procesosPersonalizados: [{
                id: 1,
                nombrePaquete: '',
                descripcion: '',
                puntuacion: '',
                observaciones: '',
                fechaVisita: '',
                archivos: [],
                enlaces: []
              }]
            }
          }
        }
      }));
      
      setNewCentroNombre('');
      setNewCentroDelegado('');
      setNewCentroAudiologo('');
      setNewCentroFranquiciaSucursal('');
      setShowCentroModal(false);
      setActiveCentro(newId);
    }
  };

  const startEditingCentro = (centro) => {
    setEditingCentroId(centro.id);
    setEditingCentroNombre(centro.nombre);
    setEditingCentroDelegado(centro.delegado);
    setEditingCentroAudiologo(centro.audiologo);
    setEditingCentroFranquiciaSucursal(centro.franquiciaSucursal);
  };

  const saveEditCentro = () => {
    if (editingCentroNombre.trim()) {
      setCentros(centros.map(c => 
        c.id === editingCentroId 
          ? {
              ...c,
              nombre: editingCentroNombre.trim(),
              delegado: editingCentroDelegado.trim(),
              audiologo: editingCentroAudiologo.trim(),
              franquiciaSucursal: editingCentroFranquiciaSucursal.trim()
            }
          : c
      ));
      setEditingCentroId(null);
      setEditingCentroNombre('');
      setEditingCentroDelegado('');
      setEditingCentroAudiologo('');
      setEditingCentroFranquiciaSucursal('');
    }
  };

  const cancelEditCentro = () => {
    setEditingCentroId(null);
    setEditingCentroNombre('');
    setEditingCentroDelegado('');
    setEditingCentroAudiologo('');
    setEditingCentroFranquiciaSucursal('');
  };

  const deleteCentro = (id) => {
    if (confirm('¿Estás seguro de eliminar este centro?')) {
      setCentros(centros.filter(c => c.id !== id));
      if (activeCentro === id) {
        setActiveCentro(centros.length > 1 ? centros[0].id : null);
      }
      
      // Eliminar datos del centro
      setData(prev => {
        const newCentrosData = { ...prev.centros_exclusivos.centrosData };
        delete newCentrosData[id];
        return {
          ...prev,
          centros_exclusivos: {
            ...prev.centros_exclusivos,
            centrosData: newCentrosData
          }
        };
      });
    }
  };

  const handleLogoUpload = (event) => {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setLogoUrl(e.target.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleFileUpload = (event) => {
    const files = Array.from(event.target.files);
    const newFiles = files.map(file => ({
      name: file.name,
      size: file.size,
      type: file.type,
      id: Date.now() + Math.random()
    }));
    setEditFiles([...editFiles, ...newFiles]);
  };

  const addLink = () => {
    if (newLinkUrl.trim()) {
      setEditLinks([...editLinks, {
        url: newLinkUrl,
        title: newLinkTitle || newLinkUrl,
        id: Date.now()
      }]);
      setNewLinkUrl('');
      setNewLinkTitle('');
    }
  };

  const removeLink = (id) => {
    setEditLinks(editLinks.filter(link => link.id !== id));
  };

  const removeFile = (id) => {
    setEditFiles(editFiles.filter(file => file.id !== id));
  };

  const startEditing = (item) => {
    setEditingItem(item.id);
    setEditTitle(item.title);
    setEditFecha(item.fecha || '');
    setEditAccion(item.accion || '');
    setEditDerivacion(item.derivacion || 0);
    setEditCita(item.cita || 0);
    setEditObservaciones(item.observaciones || '');
    setEditCustomData(item.customData || {});
    setEditFiles(item.files || []);
    setEditLinks(item.links || []);
  };

  const saveEdit = () => {
    if (activeData.requiresCentro && activeCentro) {
      setData(prev => ({
        ...prev,
        [activeSection]: {
          ...prev[activeSection],
          centrosData: {
            ...prev[activeSection].centrosData,
            [activeCentro]: {
              ...prev[activeSection].centrosData[activeCentro],
              items: prev[activeSection].centrosData[activeCentro].items.map(item =>
                item.id === editingItem ? { 
                  ...item, 
                  title: editTitle,
                  fecha: editFecha,
                  accion: editAccion,
                  derivacion: editDerivacion,
                  cita: editCita,
                  observaciones: editObservaciones,
                  customData: editCustomData,
                  files: editFiles,
                  links: editLinks
                } : item
              )
            }
          }
        }
      }));
    } else {
      setData(prev => ({
        ...prev,
        [activeSection]: {
          ...prev[activeSection],
          items: prev[activeSection].items.map(item =>
            item.id === editingItem ? { 
              ...item, 
              title: editTitle,
              fecha: editFecha,
              accion: editAccion,
              derivacion: editDerivacion,
              cita: editCita,
              observaciones: editObservaciones,
              customData: editCustomData,
              files: editFiles,
              links: editLinks
            } : item
          )
        }
      }));
    }
    setEditingItem(null);
    setEditTitle('');
    setEditFecha('');
    setEditAccion('');
    setEditDerivacion(0);
    setEditCita(0);
    setEditObservaciones('');
    setEditCustomData({});
    setEditFiles([]);
    setEditLinks([]);
  };

  const cancelEdit = () => {
    setEditingItem(null);
    setEditTitle('');
    setEditFecha('');
    setEditAccion('');
    setEditDerivacion(0);
    setEditCita(0);
    setEditObservaciones('');
    setEditCustomData({});
    setEditFiles([]);
    setEditLinks([]);
  };

  const addNewItem = () => {
    const currentItems = currentData.items || [];
    const newId = Math.max(...(currentItems.length > 0 ? currentItems.map(i => i.id) : [0]), 0) + 1;
    const customData = {};
    (currentData.customFields || []).forEach(field => {
      customData[field] = '';
    });
    
    const newItem = {
      id: newId,
      title: 'Nuevo Procedimiento',
      fecha: '',
      accion: '',
      derivacion: 0,
      cita: 0,
      observaciones: '',
      customData: customData,
      files: [],
      links: []
    };
    
    if (activeData.requiresCentro && activeCentro) {
      setData(prev => ({
        ...prev,
        [activeSection]: {
          ...prev[activeSection],
          centrosData: {
            ...prev[activeSection].centrosData,
            [activeCentro]: {
              ...prev[activeSection].centrosData[activeCentro],
              items: [...(prev[activeSection].centrosData[activeCentro]?.items || []), newItem]
            }
          }
        }
      }));
    } else {
      setData(prev => ({
        ...prev,
        [activeSection]: {
          ...prev[activeSection],
          items: [...prev[activeSection].items, newItem]
        }
      }));
    }
  };

  const deleteItem = (id) => {
    if (confirm('¿Estás seguro de eliminar este procedimiento?')) {
      if (activeData.requiresCentro && activeCentro) {
        setData(prev => ({
          ...prev,
          [activeSection]: {
            ...prev[activeSection],
            centrosData: {
              ...prev[activeSection].centrosData,
              [activeCentro]: {
                ...prev[activeSection].centrosData[activeCentro],
                items: prev[activeSection].centrosData[activeCentro].items.filter(item => item.id !== id)
              }
            }
          }
        }));
      } else {
        setData(prev => ({
          ...prev,
          [activeSection]: {
            ...prev[activeSection],
            items: prev[activeSection].items.filter(item => item.id !== id)
          }
        }));
      }
    }
  };

  const addCustomField = () => {
    if (newFieldName.trim()) {
      if (activeData.requiresCentro && activeCentro) {
        setData(prev => ({
          ...prev,
          [activeSection]: {
            ...prev[activeSection],
            centrosData: {
              ...prev[activeSection].centrosData,
              [activeCentro]: {
                customFields: [...(prev[activeSection].centrosData[activeCentro]?.customFields || []), newFieldName.trim()],
                items: (prev[activeSection].centrosData[activeCentro]?.items || []).map(item => ({
                  ...item,
                  customData: {
                    ...(item.customData || {}),
                    [newFieldName.trim()]: ''
                  }
                }))
              }
            }
          }
        }));
      } else {
        setData(prev => ({
          ...prev,
          [activeSection]: {
            ...prev[activeSection],
            customFields: [...(prev[activeSection].customFields || []), newFieldName.trim()],
            items: prev[activeSection].items.map(item => ({
              ...item,
              customData: {
                ...(item.customData || {}),
                [newFieldName.trim()]: ''
              }
            }))
          }
        }));
      }
      setNewFieldName('');
      setShowFieldModal(false);
    }
  };

  const removeCustomField = (fieldName) => {
    if (confirm(\`¿Eliminar el campo "\${fieldName}"?\`)) {
      if (activeData.requiresCentro && activeCentro) {
        setData(prev => ({
          ...prev,
          [activeSection]: {
            ...prev[activeSection],
            centrosData: {
              ...prev[activeSection].centrosData,
              [activeCentro]: {
                customFields: prev[activeSection].centrosData[activeCentro].customFields.filter(f => f !== fieldName),
                items: prev[activeSection].centrosData[activeCentro].items.map(item => {
                  const newCustomData = { ...item.customData };
                  delete newCustomData[fieldName];
                  return {
                    ...item,
                    customData: newCustomData
                  };
                })
              }
            }
          }
        }));
      } else {
        setData(prev => ({
          ...prev,
          [activeSection]: {
            ...prev[activeSection],
            customFields: prev[activeSection].customFields.filter(f => f !== fieldName),
            items: prev[activeSection].items.map(item => {
              const newCustomData = { ...item.customData };
              delete newCustomData[fieldName];
              return {
                ...item,
                customData: newCustomData
              };
            })
          }
        }));
      }
    }
  };

  const startEditingSection = (sectionId) => {
    setEditingSectionId(sectionId);
    setEditingSectionName(data[sectionId].title);
    setShowSectionEditModal(true);
  };

  const saveSectionEdit = () => {
    if (editingSectionName.trim()) {
      setData(prev => ({
        ...prev,
        [editingSectionId]: {
          ...prev[editingSectionId],
          title: editingSectionName.trim()
        }
      }));
    }
    setShowSectionEditModal(false);
    setEditingSectionId(null);
    setEditingSectionName('');
  };

  const addNewSection = () => {
    const newId = \`section_\${Date.now()}\`;
    setData(prev => ({
      ...prev,
      [newId]: {
        title: 'Nueva Sección',
        icon: FileText,
        color: 'from-red-600 to-red-700',
        customFields: [],
        items: []
      }
    }));
  };

  const handleExcelImport = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    try {
      const XLSX = await import('https://cdn.sheetjs.com/xlsx-0.20.0/package/xlsx.mjs');
      
      const arrayBuffer = await file.arrayBuffer();
      const workbook = XLSX.read(arrayBuffer);
      const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
      const jsonData = XLSX.utils.sheet_to_json(firstSheet);

      if (jsonData.length > 0) {
        const headers = Object.keys(jsonData[0]);
        const titleField = headers.find(h => h.toLowerCase().includes('título') || h.toLowerCase().includes('title')) || headers[0];
        const contentField = headers.find(h => h.toLowerCase().includes('contenido') || h.toLowerCase().includes('content')) || headers[1];
        
        const customFields = headers.filter(h => h !== titleField && h !== contentField);
        
        const newItems = jsonData.map((row, index) => {
          const customData = {};
          customFields.forEach(field => {
            customData[field] = row[field] || '';
          });
          
          return {
            id: Date.now() + index,
            title: row[titleField] || 'Sin título',
            content: row[contentField] || 'Sin contenido',
            customData: customData,
            files: [],
            links: []
          };
        });

        setData(prev => ({
          ...prev,
          [activeSection]: {
            ...prev[activeSection],
            customFields: [...new Set([...(prev[activeSection].customFields || []), ...customFields])],
            items: [...prev[activeSection].items, ...newItems]
          }
        }));

        alert(\`✅ Importados \${newItems.length} procedimientos desde Excel\`);
      }
    } catch (error) {
      alert('❌ Error al importar el archivo Excel.');
      console.error(error);
    }
    
    event.target.value = '';
  };

  const downloadAsJSON = () => {
    const exportData = {
      data,
      logo: logoUrl,
      companyName: companyName
    };
    const dataStr = JSON.stringify(exportData, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', 'audiologia_completo.json');
    linkElement.click();
  };

  const downloadAsExcel = async () => {
    try {
      const XLSX = await import('https://cdn.sheetjs.com/xlsx-0.20.0/package/xlsx.mjs');
      
      const exportData = activeData.items.map(item => {
        const row = {
          'Título': item.title,
          'Contenido': item.content,
          ...(item.customData || {})
        };
        return row;
      });

      const worksheet = XLSX.utils.json_to_sheet(exportData);
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, activeData.title);
      
      XLSX.writeFile(workbook, \`\${activeData.title.replace(/\\s+/g, '_')}.xlsx\`);
    } catch (error) {
      alert('Error al exportar a Excel');
      console.error(error);
    }
  };

  const downloadAsText = () => {
    let textContent = '═══════════════════════════════════════════════════════\\n';
    textContent += \`    \${companyName.toUpperCase()}\\n\`;
    textContent += '    SISTEMA DE GESTIÓN DE AUDIOLOGÍA\\n';
    textContent += '═══════════════════════════════════════════════════════\\n\\n';

    sections.forEach(section => {
      textContent += `\\n\\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\\n`;
      textContent += \`\${section.title.toUpperCase()}\\n\`;
      textContent += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\\n\\n`;
      
      section.items.forEach((item, index) => {
        textContent += \`\${index + 1}. \${item.title}\\n\`;
        textContent += \`\${'─'.repeat(50)}\\n\`;
        textContent += \`\${item.content}\\n\`;
        
        if (item.customData && Object.keys(item.customData).length > 0) {
          textContent += `\\nCampos adicionales:\\n`;
          Object.entries(item.customData).forEach(([key, value]) => {
            textContent += \`  • \${key}: \${value}\\n\`;
          });
        }
        
        if (item.links && item.links.length > 0) {
          textContent += `\\nEnlaces:\\n`;
          item.links.forEach(link => {
            textContent += \`  • \${link.title}: \${link.url}\\n\`;
          });
        }
        
        if (item.files && item.files.length > 0) {
          textContent += `\\nArchivos adjuntos:\\n`;
          item.files.forEach(file => {
            textContent += \`  • \${file.name}\\n\`;
          });
        }
        textContent += `\\n`;
      });
    });

    textContent += '\\n\\n═══════════════════════════════════════════════════════\\n';
    textContent += \`Generado el: \${new Date().toLocaleString('es-ES')}\\n\`;
    textContent += '═══════════════════════════════════════════════════════\\n';

    const blob = new Blob([textContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', url);
    linkElement.setAttribute('download', 'audiologia_procedimientos.txt');
    linkElement.click();
    URL.revokeObjectURL(url);
  };

  const downloadFullHTML = () => {
    const htmlContent = `<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${companyName} - Sistema de Gestión de Audiología</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-br from-gray-100 to-gray-200 min-h-screen">
    <div class="bg-white border-b-4 border-red-600 shadow-xl">
        <div class="max-w-7xl mx-auto px-6 py-6">
            <div class="flex items-center gap-4">
                ${logoUrl ? `<img src="${logoUrl}" alt="Logo" class="h-16 w-auto object-contain">` : ''}
                <div>
                    <h1 class="text-4xl font-bold text-gray-800">${companyName}</h1>
                    <p class="text-red-600 text-lg">Sistema de Gestión de Audiología</p>
                </div>
            </div>
        </div>
    </div>

    <div class="max-w-7xl mx-auto px-6 py-8">
        ${sections.map(section => `
            <div class="mb-8 bg-white rounded-xl shadow-lg p-6 border-l-4 border-red-600">
                <h2 class="text-3xl font-bold text-gray-800 mb-6">${section.title}</h2>
                ${section.items.map((item, idx) => `
                    <div class="mb-6 bg-gray-50 border border-gray-200 rounded-lg p-5">
                        <h3 class="text-xl font-semibold text-gray-800 mb-3">${idx + 1}. ${item.title}</h3>
                        ${Object.keys(item.customData || {}).length > 0 ? `
                            <div class="grid grid-cols-2 gap-2 mb-3">
                                ${Object.entries(item.customData).map(([key, value]) => `
                                    <div class="bg-white rounded p-2 border border-gray-200">
                                        <span class="text-red-600 text-sm font-semibold">${key}:</span>
                                        <span class="text-gray-700 text-sm ml-2">${value || '-'}</span>
                                    </div>
                                `).join('')}
                            </div>
                        ` : ''}
                        <div class="text-gray-700 whitespace-pre-line leading-relaxed mb-3">${item.content}</div>
                        ${(item.links && item.links.length > 0) ? `
                            <div class="mt-3">
                                <p class="text-sm font-semibold text-gray-700 mb-2">Enlaces:</p>
                                ${item.links.map(link => `
                                    <a href="${link.url}" target="_blank" class="text-red-600 hover:text-red-800 text-sm block">🔗 ${link.title}</a>
                                `).join('')}
                            </div>
                        ` : ''}
                        ${(item.files && item.files.length > 0) ? `
                            <div class="mt-3">
                                <p class="text-sm font-semibold text-gray-700 mb-2">Archivos adjuntos:</p>
                                ${item.files.map(file => `
                                    <div class="text-gray-600 text-sm">📎 ${file.name}</div>
                                `).join('')}
                            </div>
                        ` : ''}
                    </div>
                `).join('')}
            </div>
        `).join('')}
    </div>

    <footer class="text-center text-gray-600 py-6 bg-white border-t">
        <p>Generado el ${new Date().toLocaleString('es-ES')}</p>
    </footer>
</body>
</html>`;

    const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', url);
    linkElement.setAttribute('download', 'audiologia_sistema_completo.html');
    linkElement.click();
    URL.revokeObjectURL(url);
  };

  const filteredItems = [];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-100 to-gray-200">
      {/* Header */}
      <div className="bg-white border-b-4 border-red-600 shadow-xl">
        <div className="max-w-7xl mx-auto px-6 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              {logoUrl ? (
                <img src={logoUrl} alt="Logo" className="h-16 w-auto object-contain cursor-pointer hover:opacity-80 transition" onClick={() => setShowLogoModal(true)} />
              ) : (
                <div className="bg-gradient-to-br from-red-600 to-red-700 p-4 rounded-xl shadow-lg cursor-pointer hover:shadow-xl transition" onClick={() => setShowLogoModal(true)}>
                  <Image className="w-8 h-8 text-white" />
                </div>
              )}
              <div>
                <h1 className="text-3xl font-bold text-gray-800 cursor-pointer hover:text-red-600 transition" onClick={() => setShowLogoModal(true)}>
                  {companyName}
                </h1>
                <p className="text-red-600 mt-1">Sistema de Gestión de Audiología</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input
                  type="text"
                  placeholder="Buscar procedimientos..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 pr-4 py-2 bg-white border-2 border-gray-300 text-gray-800 placeholder-gray-400 rounded-lg focus:border-red-600 focus:outline-none w-64"
                />
              </div>
              <button
                onClick={() => setShowLogoModal(true)}
                className="flex items-center gap-2 bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700 transition-all shadow-md hover:shadow-lg"
              >
                <Image className="w-5 h-5" />
                Logo
              </button>
              <label className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-all shadow-md hover:shadow-lg cursor-pointer">
                <Upload className="w-5 h-5" />
                Importar
                <input
                  type="file"
                  accept=".xlsx,.xls"
                  onChange={handleExcelImport}
                  className="hidden"
                />
              </label>
              <div className="relative group">
                <button className="flex items-center gap-2 bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-all shadow-md hover:shadow-lg">
                  <Download className="w-5 h-5" />
                  Descargar
                </button>
                <div className="absolute right-0 mt-2 w-64 bg-white rounded-lg shadow-2xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all z-50 border border-gray-200">
                  <button
                    onClick={downloadFullHTML}
                    className="w-full text-left px-4 py-3 hover:bg-red-50 rounded-t-lg text-gray-700 font-medium flex items-center gap-2"
                  >
                    <span className="text-2xl">🌐</span>
                    <div>
                      <div>Página Web (HTML)</div>
                      <div className="text-xs text-gray-500">Archivo completo editable</div>
                    </div>
                  </button>
                  <button
                    onClick={downloadAsText}
                    className="w-full text-left px-4 py-3 hover:bg-red-50 text-gray-700 font-medium flex items-center gap-2"
                  >
                    <span className="text-2xl">📄</span>
                    <div>
                      <div>Documento de Texto</div>
                      <div className="text-xs text-gray-500">Formato .txt</div>
                    </div>
                  </button>
                  <button
                    onClick={downloadAsExcel}
                    className="w-full text-left px-4 py-3 hover:bg-red-50 text-gray-700 font-medium flex items-center gap-2"
                  >
                    <span className="text-2xl">📊</span>
                    <div>
                      <div>Excel (Sección Actual)</div>
                      <div className="text-xs text-gray-500">Formato .xlsx</div>
                    </div>
                  </button>
                  <button
                    onClick={downloadAsJSON}
                    className="w-full text-left px-4 py-3 hover:bg-red-50 rounded-b-lg text-gray-700 font-medium flex items-center gap-2"
                  >
                    <span className="text-2xl">💾</span>
                    <div>
                      <div>Backup Completo</div>
                      <div className="text-xs text-gray-500">Formato .json</div>
                    </div>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="grid grid-cols-12 gap-6">
          {/* Sidebar */}
          <div className="col-span-3">
            <div className="bg-white rounded-xl shadow-lg p-4 border-l-4 border-red-600">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold text-gray-800 px-2">
                  Secciones
                </h2>
                <button
                  onClick={addNewSection}
                  className="p-1 bg-red-600 text-white rounded-lg hover:bg-red-700 transition"
                  title="Añadir nueva sección"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
              <nav className="space-y-2">
                {sections.map((section) => {
                  const Icon = section.icon;
                  const isActive = activeSection === section.id;
                  return (
                    <div key={section.id}>
                      <div className="relative group">
                        <button
                          onClick={() => {
                            setActiveSection(section.id);
                            if (section.requiresCentro) {
                              setShowCentrosDropdown(!showCentrosDropdown);
                              if (centros.length > 0 && !activeCentro) {
                                setActiveCentro(centros[0].id);
                              }
                            }
                          }}
                          className={`w-full flex items-center justify-between gap-3 px-4 py-3 rounded-lg transition-all ${
                            isActive
                              ? 'bg-red-600 text-white shadow-md'
                              : 'text-gray-700 bg-gray-50 hover:bg-gray-100'
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            <Icon className="w-5 h-5" />
                            <span className="font-medium text-sm">{section.title}</span>
                          </div>
                          {section.requiresCentro && (
                            <div className="flex items-center gap-1">
                              {showCentrosDropdown && isActive && (
                                <span className="text-xs bg-white/20 px-2 py-0.5 rounded-full">
                                  {centros.length}/12
                                </span>
                              )}
                              {showCentrosDropdown && isActive ? (
                                <ChevronDown className="w-5 h-5 font-bold" />
                              ) : (
                                <ChevronRight className="w-5 h-5 font-bold" />
                              )}
                            </div>
                          )}
                          {!section.requiresCentro && isActive && <ChevronRight className="w-4 h-4" />}
                        </button>
                        {!section.requiresCentro && (
                          <button
                            onClick={() => startEditingSection(section.id)}
                            className="absolute right-2 top-2 opacity-0 group-hover:opacity-100 p-1 bg-gray-200 hover:bg-gray-300 rounded transition"
                            title="Editar nombre de sección"
                          >
                            <Pencil className="w-3 h-3 text-gray-700" />
                          </button>
                        )}
                      </div>
                      
                      {/* Desplegable de centros */}
                      {isActive && section.requiresCentro && showCentrosDropdown && (
                        <div className="ml-2 mt-1 bg-gray-100 rounded-lg p-2 border border-gray-200">
                          <div className="space-y-1">
                            {centros.map(centro => (
                              <div key={centro.id} className="relative group">
                                {editingCentroId === centro.id ? (
                                  <div className="bg-white border-2 border-red-600 rounded-lg p-2 space-y-2 shadow-lg">
                                    <input
                                      type="text"
                                      value={editingCentroNombre}
                                      onChange={(e) => setEditingCentroNombre(e.target.value)}
                                      placeholder="Nombre del centro"
                                      className="w-full bg-white text-gray-800 border border-gray-300 rounded px-2 py-1 text-xs focus:outline-none focus:border-red-600"
                                    />
                                    <input
                                      type="text"
                                      value={editingCentroDelegado}
                                      onChange={(e) => setEditingCentroDelegado(e.target.value)}
                                      placeholder="Delegado"
                                      className="w-full bg-white text-gray-800 border border-gray-300 rounded px-2 py-1 text-xs focus:outline-none focus:border-red-600"
                                    />
                                    <input
                                      type="text"
                                      value={editingCentroAudiologo}
                                      onChange={(e) => setEditingCentroAudiologo(e.target.value)}
                                      placeholder="Audiólogo"
                                      className="w-full bg-white text-gray-800 border border-gray-300 rounded px-2 py-1 text-xs focus:outline-none focus:border-red-600"
                                    />
                                    <select
                                      value={editingCentroFranquiciaSucursal}
                                      onChange={(e) => setEditingCentroFranquiciaSucursal(e.target.value)}
                                      className="w-full bg-white text-gray-800 border border-gray-300 rounded px-2 py-1 text-xs focus:outline-none focus:border-red-600"
                                    >
                                      <option value="">Seleccionar...</option>
                                      <option value="Franquicia">Franquicia</option>
                                      <option value="Sucursal">Sucursal</option>
                                    </select>
                                    <div className="flex gap-1">
                                      <button
                                        onClick={saveEditCentro}
                                        className="flex-1 bg-green-600 text-white px-2 py-1 rounded text-xs hover:bg-green-700 transition font-semibold"
                                      >
                                        ✓ Guardar
                                      </button>
                                      <button
                                        onClick={cancelEditCentro}
                                        className="flex-1 bg-gray-500 text-white px-2 py-1 rounded text-xs hover:bg-gray-600 transition"
                                      >
                                        ✕ Cancelar
                                      </button>
                                    </div>
                                  </div>
                                ) : (
                                  <div className="flex items-center gap-1">
                                    <button
                                      onClick={() => setActiveCentro(centro.id)}
                                      className={`flex-1 text-left px-2 py-1.5 rounded-md text-xs transition-all border-2 ${
                                        activeCentro === centro.id
                                          ? centro.color
                                          : 'bg-white text-gray-700 border-gray-200 hover:border-gray-300'
                                      }`}
                                    >
                                      <div className="font-bold truncate">{centro.nombre}</div>
                                      <div className="text-xs opacity-75 truncate">
                                        👤 {centro.delegado} | 🎧 {centro.audiologo}
                                      </div>
                                      <div className="text-xs opacity-75">
                                        📍 {centro.franquiciaSucursal || '-'}
                                      </div>
                                    </button>
                                    <div className="flex flex-col gap-1">
                                      <button
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          startEditingCentro(centro);
                                        }}
                                        className="p-1 bg-blue-500 hover:bg-blue-600 text-white rounded transition"
                                        title="Editar"
                                      >
                                        <Pencil className="w-3 h-3" />
                                      </button>
                                      <button
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          deleteCentro(centro.id);
                                        }}
                                        className="p-1 bg-red-500 hover:bg-red-600 text-white rounded transition"
                                        title="Eliminar"
                                      >
                                        <X className="w-3 h-3" />
                                      </button>
                                    </div>
                                  </div>
                                )}
                              </div>
                            ))}
                            {centros.length < 12 && (
                              <button
                                onClick={() => setShowCentroModal(true)}
                                className="w-full flex items-center justify-center gap-1 px-2 py-1.5 bg-green-600 text-white rounded-md hover:bg-green-700 transition text-xs font-semibold shadow-sm"
                              >
                                <Plus className="w-3 h-3" />
                                Añadir ({centros.length}/12)
                              </button>
                            )}
                            {centros.length >= 12 && (
                              <div className="text-center text-xs text-gray-500 py-1">
                                ✓ Máximo alcanzado (12/12)
                              </div>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </nav>
            </div>
          </div>

          {/* Main Content */}
          <div className="col-span-9">
            <div className="bg-white rounded-xl shadow-lg p-6 border-l-4 border-red-600">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3">
                  <div className="bg-red-600 p-3 rounded-lg shadow-md">
                    {React.createElement(activeData.icon, { className: "w-6 h-6 text-white" })}
                  </div>
                  <div>
                    <h2 className="text-2xl font-bold text-gray-800">{activeData.title}</h2>
                    {activeData.requiresCentro && activeCentro && (
                      <div className="mt-1">
                        <span className={`inline-block px-3 py-1 rounded-lg text-sm font-semibold border-2 ${
                          centros.find(c => c.id === activeCentro)?.color || 'bg-gray-100 border-gray-300 text-gray-800'
                        }`}>
                          {centros.find(c => c.id === activeCentro)?.nombre}
                        </span>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              <div className="space-y-6">
                {activeData.requiresCentro && !activeCentro ? (
                  <div className="text-center py-12 text-gray-500 text-lg">
                    Selecciona o añade un centro para ver los procedimientos
                  </div>
                ) : (
                  <>
                    {/* Sección Acciones-Resultado */}
                    <div className="bg-gray-50 border-2 border-gray-200 rounded-lg p-5">
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="text-2xl font-bold text-gray-800">Acciones-Resultado</h3>
                        <div className="flex gap-2">
                          <button
                            onClick={addAccion}
                            className="flex items-center gap-2 px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition shadow-md text-sm"
                          >
                            <Plus className="w-4 h-4" />
                            Añadir
                          </button>
                          <button
                            onClick={saveAccionesResultado}
                            className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition shadow-md"
                          >
                            <Save className="w-4 h-4" />
                            Guardar
                          </button>
                        </div>
                      </div>

                      {/* Tabla estilo Excel */}
                      <div className="overflow-x-auto">
                        <table className="w-full border-collapse bg-white rounded-lg overflow-hidden shadow-sm">
                          <thead>
                            <tr className="bg-red-600 text-white">
                              <th className="border border-gray-300 px-2 py-2 text-sm font-bold w-8">↕</th>
                              <th className="border border-gray-300 px-3 py-2 text-sm font-bold w-12">#</th>
                              <th className="border border-gray-300 px-3 py-2 text-sm font-bold w-32">Fecha</th>
                              <th className="border border-gray-300 px-3 py-2 text-sm font-bold w-40">Acción</th>
                              <th className="border border-gray-300 px-3 py-2 text-sm font-bold w-24">Derivación</th>
                              <th className="border border-gray-300 px-3 py-2 text-sm font-bold w-24">Cita</th>
                              <th className="border border-gray-300 px-3 py-2 text-sm font-bold">Observaciones</th>
                              <th className="border border-gray-300 px-3 py-2 text-sm font-bold w-16">❌</th>
                            </tr>
                          </thead>
                          <tbody>
                            {accionesResultadoData.map((accion, index) => {
                              const isGreen = (accion.derivacion || 0) > 0 && (accion.cita || 0) > 0;
                              
                              return (
                                <tr
                                  key={accion.id}
                                  draggable
                                  onDragStart={() => handleDragStartAccion(index)}
                                  onDragOver={(e) => handleDragOverAccion(e, index)}
                                  onDragEnd={handleDragEndAccion}
                                  className={`${isGreen ? 'bg-green-100' : 'bg-white'} hover:bg-opacity-80 transition ${
                                    draggedAccionIndex === index ? 'opacity-50' : 'opacity-100'
                                  }`}
                                >
                                  <td className="border border-gray-300 px-2 py-2 text-center cursor-move">
                                    <div className="flex flex-col items-center gap-1">
                                      <div className="w-1 h-1 bg-gray-400 rounded-full"></div>
                                      <div className="w-1 h-1 bg-gray-400 rounded-full"></div>
                                      <div className="w-1 h-1 bg-gray-400 rounded-full"></div>
                                    </div>
                                  </td>
                                  <td className="border border-gray-300 px-3 py-2 text-center">
                                    <span className="inline-flex items-center justify-center w-6 h-6 bg-red-600 text-white rounded-full text-xs font-bold">
                                      {index + 1}
                                    </span>
                                  </td>
                                  <td className="border border-gray-300 px-2 py-1">
                                    <input
                                      type="date"
                                      value={accion.fecha}
                                      onChange={(e) => updateAccion(accion.id, 'fecha', e.target.value)}
                                      className="w-full bg-transparent border-none text-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-red-400 rounded px-1 py-1"
                                    />
                                  </td>
                                  <td className="border border-gray-300 px-2 py-1">
                                    <input
                                      type="text"
                                      value={accion.accion}
                                      onChange={(e) => updateAccion(accion.id, 'accion', e.target.value)}
                                      placeholder="Descripción..."
                                      className="w-full bg-transparent border-none text-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-red-400 rounded px-1 py-1"
                                    />
                                  </td>
                                  <td className="border border-gray-300 px-2 py-1">
                                    <input
                                      type="number"
                                      min="0"
                                      value={accion.derivacion}
                                      onChange={(e) => updateAccion(accion.id, 'derivacion', parseInt(e.target.value) || 0)}
                                      className="w-full bg-transparent border-none text-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-red-400 rounded px-1 py-1 text-center font-bold"
                                    />
                                  </td>
                                  <td className="border border-gray-300 px-2 py-1">
                                    <input
                                      type="number"
                                      min="0"
                                      value={accion.cita}
                                      onChange={(e) => updateAccion(accion.id, 'cita', parseInt(e.target.value) || 0)}
                                      className="w-full bg-transparent border-none text-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-red-400 rounded px-1 py-1 text-center font-bold"
                                    />
                                  </td>
                                  <td className="border border-gray-300 px-2 py-1">
                                    <input
                                      type="text"
                                      value={accion.observaciones}
                                      onChange={(e) => updateAccion(accion.id, 'observaciones', e.target.value)}
                                      placeholder="Observaciones..."
                                      className="w-full bg-transparent border-none text-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-red-400 rounded px-1 py-1"
                                    />
                                  </td>
                                  <td className="border border-gray-300 px-2 py-2 text-center">
                                    <button
                                      onClick={() => deleteAccion(accion.id)}
                                      disabled={accionesResultadoData.length === 1}
                                      className={`p-1 rounded transition ${
                                        accionesResultadoData.length === 1
                                          ? 'text-gray-300 cursor-not-allowed'
                                          : 'text-red-600 hover:bg-red-100'
                                      }`}
                                      title="Eliminar"
                                    >
                                      <X className="w-4 h-4" />
                                    </button>
                                  </td>
                                </tr>
                              );
                            })}
                          </tbody>
                        </table>
                      </div>
                    </div>

                    {/* Sección Formación Continua */}
                    <div className="bg-gray-50 border-2 border-gray-200 rounded-lg p-5">
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="text-2xl font-bold text-gray-800">Formación Continua</h3>
                        <button
                          onClick={saveFormaciones}
                          className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition shadow-md"
                        >
                          <Save className="w-4 h-4" />
                          Guardar
                        </button>
                      </div>

                      {/* Tabla estilo Excel */}
                      <div className="overflow-x-auto">
                        <table className="w-full border-collapse bg-white rounded-lg overflow-hidden shadow-sm">
                          <thead>
                            <tr className="bg-red-600 text-white">
                              <th className="border border-gray-300 px-2 py-2 text-sm font-bold w-8">↕</th>
                              <th className="border border-gray-300 px-3 py-2 text-sm font-bold w-12">#</th>
                              <th className="border border-gray-300 px-3 py-2 text-sm font-bold w-32">Fecha</th>
                              <th className="border border-gray-300 px-3 py-2 text-sm font-bold w-28">Asistencia</th>
                              <th className="border border-gray-300 px-3 py-2 text-sm font-bold">Título Formación</th>
                              <th className="border border-gray-300 px-3 py-2 text-sm font-bold">Aplicación</th>
                            </tr>
                          </thead>
                          <tbody>
                            {formacionesData.map((formacion, index) => {
                              const asiste = formacion.asistencia?.toLowerCase() === 'si' || formacion.asistencia?.toLowerCase() === 'sí';
                              const aplica = formacion.aplicacion?.toLowerCase() === 'si' || formacion.aplicacion?.toLowerCase() === 'sí' || (formacion.aplicacion && formacion.aplicacion.trim().length > 2);
                              
                              let bgColor = 'bg-white';
                              if (asiste && aplica) {
                                bgColor = 'bg-green-100';
                              } else if (asiste) {
                                bgColor = 'bg-orange-100';
                              }
                              
                              return (
                                <tr
                                  key={formacion.id}
                                  draggable
                                  onDragStart={() => handleDragStartFormacion(index)}
                                  onDragOver={(e) => handleDragOverFormacion(e, index)}
                                  onDragEnd={handleDragEndFormacion}
                                  className={`${bgColor} hover:bg-opacity-80 transition ${
                                    draggedFormacionIndex === index ? 'opacity-50' : 'opacity-100'
                                  }`}
                                >
                                  <td className="border border-gray-300 px-2 py-2 text-center cursor-move">
                                    <div className="flex flex-col items-center gap-1">
                                      <div className="w-1 h-1 bg-gray-400 rounded-full"></div>
                                      <div className="w-1 h-1 bg-gray-400 rounded-full"></div>
                                      <div className="w-1 h-1 bg-gray-400 rounded-full"></div>
                                    </div>
                                  </td>
                                  <td className="border border-gray-300 px-3 py-2 text-center">
                                    <span className="inline-flex items-center justify-center w-6 h-6 bg-red-600 text-white rounded-full text-xs font-bold">
                                      {index + 1}
                                    </span>
                                  </td>
                                  <td className="border border-gray-300 px-2 py-1">
                                    <input
                                      type="date"
                                      value={formacion.fecha}
                                      onChange={(e) => updateFormacion(formacion.id, 'fecha', e.target.value)}
                                      className="w-full bg-transparent border-none text-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-red-400 rounded px-1 py-1"
                                    />
                                  </td>
                                  <td className="border border-gray-300 px-2 py-1">
                                    <select
                                      value={formacion.asistencia}
                                      onChange={(e) => updateFormacion(formacion.id, 'asistencia', e.target.value)}
                                      className="w-full bg-transparent border-none text-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-red-400 rounded px-1 py-1 font-semibold"
                                    >
                                      <option value="">-</option>
                                      <option value="SI">SI</option>
                                      <option value="NO">NO</option>
                                      <option value="Pendiente">Pendiente</option>
                                    </select>
                                  </td>
                                  <td className="border border-gray-300 px-2 py-1">
                                    <input
                                      type="text"
                                      value={formacion.titulo}
                                      onChange={(e) => updateFormacion(formacion.id, 'titulo', e.target.value)}
                                      placeholder="Nombre del curso..."
                                      className="w-full bg-transparent border-none text-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-red-400 rounded px-1 py-1"
                                    />
                                  </td>
                                  <td className="border border-gray-300 px-2 py-1">
                                    <input
                                      type="text"
                                      value={formacion.aplicacion}
                                      onChange={(e) => updateFormacion(formacion.id, 'aplicacion', e.target.value)}
                                      placeholder="¿Cómo se aplicará? o SI/NO"
                                      className="w-full bg-transparent border-none text-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-red-400 rounded px-1 py-1"
                                    />
                                  </td>
                                </tr>
                              );
                            })}
                          </tbody>
                        </table>
                      </div>

                      {/* Leyenda */}
                      <div className="mt-3 flex items-center gap-4 text-sm">
                        <div className="flex items-center gap-2">
                          <div className="w-4 h-4 bg-orange-100 border border-orange-300 rounded"></div>
                          <span className="text-gray-700">Asistencia: SI</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="w-4 h-4 bg-green-100 border border-green-300 rounded"></div>
                          <span className="text-gray-700">Asistencia: SI + Aplicación</span>
                        </div>
                      </div>
                    </div>

                    {/* Sección Procesos y Paquetes Personalizados */}
                    <div className="bg-gray-50 border-2 border-gray-200 rounded-lg p-5">
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="text-2xl font-bold text-gray-800">Procesos y Paquetes Personalizados</h3>
                        <div className="flex gap-2">
                          <button
                            onClick={addProceso}
                            className="flex items-center gap-2 px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition shadow-md text-sm"
                          >
                            <Plus className="w-4 h-4" />
                            Añadir
                          </button>
                          <button
                            onClick={saveProcesos}
                            className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition shadow-md"
                          >
                            <Save className="w-4 h-4" />
                            Guardar
                          </button>
                        </div>
                      </div>

                      {/* Tabla estilo Excel */}
                      <div className="overflow-x-auto">
                        <table className="w-full border-collapse bg-white rounded-lg overflow-hidden shadow-sm">
                          <thead>
                            <tr className="bg-red-600 text-white">
                              <th className="border border-gray-300 px-2 py-2 text-sm font-bold w-8">↕</th>
                              <th className="border border-gray-300 px-3 py-2 text-sm font-bold w-12">#</th>
                              <th className="border border-gray-300 px-3 py-2 text-sm font-bold w-40">Nombre Paquete</th>
                              <th className="border border-gray-300 px-3 py-2 text-sm font-bold">Descripción</th>
                              <th className="border border-gray-300 px-3 py-2 text-sm font-bold w-28">Puntuación</th>
                              <th className="border border-gray-300 px-3 py-2 text-sm font-bold">Observaciones</th>
                              <th className="border border-gray-300 px-3 py-2 text-sm font-bold w-32">Fecha Visita</th>
                              <th className="border border-gray-300 px-3 py-2 text-sm font-bold w-24">📎/🔗</th>
                              <th className="border border-gray-300 px-3 py-2 text-sm font-bold w-16">❌</th>
                            </tr>
                          </thead>
                          <tbody>
                            {procesosData.map((proceso, index) => (
                              <tr
                                key={proceso.id}
                                draggable
                                onDragStart={() => handleDragStartProceso(index)}
                                onDragOver={(e) => handleDragOverProceso(e, index)}
                                onDragEnd={handleDragEndProceso}
                                className={`bg-white hover:bg-gray-50 transition ${
                                  draggedProcesoIndex === index ? 'opacity-50' : 'opacity-100'
                                }`}
                              >
                                <td className="border border-gray-300 px-2 py-2 text-center cursor-move">
                                  <div className="flex flex-col items-center gap-1">
                                    <div className="w-1 h-1 bg-gray-400 rounded-full"></div>
                                    <div className="w-1 h-1 bg-gray-400 rounded-full"></div>
                                    <div className="w-1 h-1 bg-gray-400 rounded-full"></div>
                                  </div>
                                </td>
                                <td className="border border-gray-300 px-3 py-2 text-center">
                                  <span className="inline-flex items-center justify-center w-6 h-6 bg-red-600 text-white rounded-full text-xs font-bold">
                                    {index + 1}
                                  </span>
                                </td>
                                <td className="border border-gray-300 px-2 py-1">
                                  <input
                                    type="text"
                                    value={proceso.nombrePaquete}
                                    onChange={(e) => updateProceso(proceso.id, 'nombrePaquete', e.target.value)}
                                    placeholder="Nombre del paquete..."
                                    className="w-full bg-transparent border-none text-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-red-400 rounded px-1 py-1 font-semibold"
                                  />
                                </td>
                                <td className="border border-gray-300 px-2 py-1">
                                  <input
                                    type="text"
                                    value={proceso.descripcion}
                                    onChange={(e) => updateProceso(proceso.id, 'descripcion', e.target.value)}
                                    placeholder="Descripción personalizada..."
                                    className="w-full bg-transparent border-none text-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-red-400 rounded px-1 py-1"
                                  />
                                </td>
                                <td className="border border-gray-300 px-2 py-1">
                                  <input
                                    type="text"
                                    value={proceso.puntuacion}
                                    onChange={(e) => updateProceso(proceso.id, 'puntuacion', e.target.value)}
                                    placeholder="Ej: 8/10"
                                    className="w-full bg-transparent border-none text-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-red-400 rounded px-1 py-1 text-center font-bold"
                                  />
                                </td>
                                <td className="border border-gray-300 px-2 py-1">
                                  <input
                                    type="text"
                                    value={proceso.observaciones}
                                    onChange={(e) => updateProceso(proceso.id, 'observaciones', e.target.value)}
                                    placeholder="Observaciones..."
                                    className="w-full bg-transparent border-none text-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-red-400 rounded px-1 py-1"
                                  />
                                </td>
                                <td className="border border-gray-300 px-2 py-1">
                                  <input
                                    type="date"
                                    value={proceso.fechaVisita}
                                    onChange={(e) => updateProceso(proceso.id, 'fechaVisita', e.target.value)}
                                    className="w-full bg-transparent border-none text-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-red-400 rounded px-1 py-1"
                                  />
                                </td>
                                <td className="border border-gray-300 px-2 py-2">
                                  <div className="flex gap-1 justify-center">
                                    <label className="cursor-pointer p-1 hover:bg-gray-100 rounded transition" title="Adjuntar archivo">
                                      <Paperclip className="w-4 h-4 text-gray-600" />
                                      <input
                                        type="file"
                                        multiple
                                        onChange={(e) => handleProcesoFileUpload(proceso.id, e)}
                                        className="hidden"
                                      />
                                    </label>
                                    <button
                                      onClick={() => setEditingProcesoId(editingProcesoId === proceso.id ? null : proceso.id)}
                                      className="p-1 hover:bg-gray-100 rounded transition"
                                      title="Añadir enlace"
                                    >
                                      <LinkIcon className="w-4 h-4 text-gray-600" />
                                    </button>
                                  </div>
                                  
                                  {/* Modal inline para añadir enlace */}
                                  {editingProcesoId === proceso.id && (
                                    <div className="absolute z-10 mt-2 bg-white border-2 border-red-600 rounded-lg shadow-lg p-3 w-80">
                                      <div className="space-y-2">
                                        <input
                                          type="url"
                                          value={newProcesoLinkUrl}
                                          onChange={(e) => setNewProcesoLinkUrl(e.target.value)}
                                          placeholder="URL del enlace"
                                          className="w-full bg-white text-gray-800 border border-gray-300 rounded px-2 py-1 text-sm focus:outline-none focus:border-red-600"
                                        />
                                        <input
                                          type="text"
                                          value={newProcesoLinkTitle}
                                          onChange={(e) => setNewProcesoLinkTitle(e.target.value)}
                                          placeholder="Título (opcional)"
                                          className="w-full bg-white text-gray-800 border border-gray-300 rounded px-2 py-1 text-sm focus:outline-none focus:border-red-600"
                                        />
                                        <div className="flex gap-2">
                                          <button
                                            onClick={() => addProcesoLink(proceso.id)}
                                            className="flex-1 bg-green-600 text-white px-2 py-1 rounded text-xs hover:bg-green-700 transition"
                                          >
                                            Añadir
                                          </button>
                                          <button
                                            onClick={() => setEditingProcesoId(null)}
                                            className="flex-1 bg-gray-500 text-white px-2 py-1 rounded text-xs hover:bg-gray-600 transition"
                                          >
                                            Cancelar
                                          </button>
                                        </div>
                                      </div>
                                    </div>
                                  )}
                                  
                                  {/* Mostrar archivos y enlaces */}
                                  {((proceso.archivos && proceso.archivos.length > 0) || (proceso.enlaces && proceso.enlaces.length > 0)) && (
                                    <div className="mt-2 text-xs">
                                      {proceso.archivos && proceso.archivos.map(file => (
                                        <div key={file.id} className="flex items-center justify-between bg-gray-50 px-1 py-0.5 rounded mb-1">
                                          <span className="text-gray-700 truncate">📎 {file.name}</span>
                                          <button
                                            onClick={() => removeProcesoFile(proceso.id, file.id)}
                                            className="text-red-600 hover:text-red-800"
                                          >
                                            <X className="w-3 h-3" />
                                          </button>
                                        </div>
                                      ))}
                                      {proceso.enlaces && proceso.enlaces.map(link => (
                                        <div key={link.id} className="flex items-center justify-between bg-gray-50 px-1 py-0.5 rounded mb-1">
                                          <a href={link.url} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:text-blue-800 truncate flex-1">
                                            🔗 {link.title}
                                          </a>
                                          <button
                                            onClick={() => removeProcesoLink(proceso.id, link.id)}
                                            className="text-red-600 hover:text-red-800"
                                          >
                                            <X className="w-3 h-3" />
                                          </button>
                                        </div>
                                      ))}
                                    </div>
                                  )}
                                </td>
                                <td className="border border-gray-300 px-2 py-2 text-center">
                                  <button
                                    onClick={() => deleteProceso(proceso.id)}
                                    disabled={procesosData.length === 1}
                                    className={`p-1 rounded transition ${
                                      procesosData.length === 1
                                        ? 'text-gray-300 cursor-not-allowed'
                                        : 'text-red-600 hover:bg-red-100'
                                    }`}
                                    title="Eliminar"
                                  >
                                    <X className="w-4 h-4" />
                                  </button>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Modal for Logo Upload */}
      {showLogoModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-6 border-2 border-red-600 shadow-2xl max-w-md w-full mx-4">
            <h3 className="text-2xl font-bold text-gray-800 mb-4">Personalizar Marca</h3>
            <div className="mb-4">
              <label className="text-gray-700 font-semibold block mb-2">Nombre de la Empresa</label>
              <input
                type="text"
                value={companyName}
                onChange={(e) => setCompanyName(e.target.value)}
                placeholder="Nombre de tu empresa"
                className="w-full bg-white text-gray-800 border-2 border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:border-red-600"
              />
            </div>
            <div className="mb-4">
              <label className="text-gray-700 font-semibold block mb-2">Logo Corporativo</label>
              {logoUrl && (
                <div className="mb-3 flex justify-center">
                  <img src={logoUrl} alt="Logo Preview" className="max-h-32 object-contain" />
                </div>
              )}
              <label className="flex items-center justify-center gap-2 bg-red-600 text-white px-4 py-3 rounded-lg hover:bg-red-700 transition-all cursor-pointer">
                <Upload className="w-5 h-5" />
                {logoUrl ? 'Cambiar Logo' : 'Subir Logo'}
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleLogoUpload}
                  className="hidden"
                />
              </label>
            </div>
            <div className="flex gap-3">
              <button
                onClick={() => setShowLogoModal(false)}
                className="flex-1 bg-red-600 text-white px-4 py-3 rounded-lg hover:bg-red-700 transition-all shadow-md font-semibold"
              >
                Guardar
              </button>
              <button
                onClick={() => setShowLogoModal(false)}
                className="flex-1 bg-gray-300 text-gray-700 px-4 py-3 rounded-lg hover:bg-gray-400 transition-all font-semibold"
              >
                Cancelar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal for Section Edit */}
      {showSectionEditModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-6 border-2 border-red-600 shadow-2xl max-w-md w-full mx-4">
            <h3 className="text-2xl font-bold text-gray-800 mb-4">Editar Nombre de Sección</h3>
            <input
              type="text"
              value={editingSectionName}
              onChange={(e) => setEditingSectionName(e.target.value)}
              placeholder="Nombre de la sección"
              className="w-full bg-white text-gray-800 border-2 border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:border-red-600 mb-4"
              onKeyPress={(e) => e.key === 'Enter' && saveSectionEdit()}
            />
            <div className="flex gap-3">
              <button
                onClick={saveSectionEdit}
                className="flex-1 bg-red-600 text-white px-4 py-3 rounded-lg hover:bg-red-700 transition-all shadow-md font-semibold"
              >
                Guardar
              </button>
              <button
                onClick={() => {
                  setShowSectionEditModal(false);
                  setEditingSectionId(null);
                  setEditingSectionName('');
                }}
                className="flex-1 bg-gray-300 text-gray-700 px-4 py-3 rounded-lg hover:bg-gray-400 transition-all font-semibold"
              >
                Cancelar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal for adding Centro */}
      {showCentroModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-6 border-2 border-red-600 shadow-2xl max-w-md w-full mx-4">
            <h3 className="text-2xl font-bold text-gray-800 mb-2">Añadir Nuevo Centro</h3>
            <p className="text-sm text-gray-600 mb-4">Total de centros: {centros.length}/12</p>
            <div className="space-y-3">
              <div>
                <label className="text-gray-700 font-semibold block mb-1 text-sm">Nombre del Centro *</label>
                <input
                  type="text"
                  value={newCentroNombre}
                  onChange={(e) => setNewCentroNombre(e.target.value)}
                  placeholder="Ej: Centro Madrid Norte"
                  className="w-full bg-white text-gray-800 border-2 border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-red-600"
                />
              </div>
              <div>
                <label className="text-gray-700 font-semibold block mb-1 text-sm">Delegado *</label>
                <input
                  type="text"
                  value={newCentroDelegado}
                  onChange={(e) => setNewCentroDelegado(e.target.value)}
                  placeholder="Ej: Ana Martínez"
                  className="w-full bg-white text-gray-800 border-2 border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-red-600"
                />
              </div>
              <div>
                <label className="text-gray-700 font-semibold block mb-1 text-sm">Audiólogo *</label>
                <input
                  type="text"
                  value={newCentroAudiologo}
                  onChange={(e) => setNewCentroAudiologo(e.target.value)}
                  placeholder="Ej: Dr. García"
                  className="w-full bg-white text-gray-800 border-2 border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-red-600"
                />
              </div>
              <div>
                <label className="text-gray-700 font-semibold block mb-1 text-sm">Tipo *</label>
                <select
                  value={newCentroFranquiciaSucursal}
                  onChange={(e) => setNewCentroFranquiciaSucursal(e.target.value)}
                  className="w-full bg-white text-gray-800 border-2 border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-red-600"
                >
                  <option value="">Seleccionar tipo...</option>
                  <option value="Franquicia">Franquicia</option>
                  <option value="Sucursal">Sucursal</option>
                </select>
              </div>
            </div>
            <div className="flex gap-3 mt-6">
              <button
                onClick={addNewCentro}
                className="flex-1 bg-red-600 text-white px-4 py-3 rounded-lg hover:bg-red-700 transition-all shadow-md font-semibold"
              >
                Añadir Centro
              </button>
              <button
                onClick={() => {
                  setShowCentroModal(false);
                  setNewCentroNombre('');
                  setNewCentroDelegado('');
                  setNewCentroAudiologo('');
                  setNewCentroFranquiciaSucursal('');
                }}
                className="flex-1 bg-gray-300 text-gray-700 px-4 py-3 rounded-lg hover:bg-gray-400 transition-all font-semibold"
              >
                Cancelar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal for adding custom fields */}
      {showFieldModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-6 border-2 border-red-600 shadow-2xl max-w-md w-full mx-4">
            <h3 className="text-2xl font-bold text-gray-800 mb-4">Añadir Campo Personalizado</h3>
            <p className="text-gray-600 mb-4">Este campo se añadirá a todos los procedimientos de esta sección</p>
            <input
              type="text"
              value={newFieldName}
              onChange={(e) => setNewFieldName(e.target.value)}
              placeholder="Nombre del campo (ej: Responsable, Fecha, Prioridad...)"
              className="w-full bg-white text-gray-800 border-2 border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:border-red-600 mb-4"
              onKeyPress={(e) => e.key === 'Enter' && addCustomField()}
            />
            <div className="flex gap-3">
              <button
                onClick={addCustomField}
                className="flex-1 bg-red-600 text-white px-4 py-3 rounded-lg hover:bg-red-700 transition-all shadow-md font-semibold"
              >
                Añadir Campo
              </button>
              <button
                onClick={() => {
                  setShowFieldModal(false);
                  setNewFieldName('');
                }}
                className="flex-1 bg-gray-300 text-gray-700 px-4 py-3 rounded-lg hover:bg-gray-400 transition-all font-semibold"
              >
                Cancelar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AudiologiaApp;